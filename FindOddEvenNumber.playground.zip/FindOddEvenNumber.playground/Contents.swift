//: Playground - noun: a place where people can play


/*  We will determine whether a number is odd or even by using different methods all are provided with a code in c language. As you have study in mathematics that in decimal number system even numbers are divisible by 2 while odd are not so we may use modulus operator(%) which returns remainder, For example 4%3 gives 1 ( remainder when four is divided by three). Even numbers are of the form 2*p and odd are of the form (2*p+1) where p is is an integer. */

var number = 5
if number % 2 == 0 {
    print("number is even")
} else {
    print("number is odd")
}


func oddEven(n: Int) -> String {
    if n % 2 == 0 {
        return "\(n) Even"
    } else {
        return "\(n) Odd"
    }
}
oddEven(n: 20)
oddEven(n: 5)