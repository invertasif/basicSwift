//: Playground - noun: a place where people can play

import Foundation


/*  perform the basic arithmetic operation of addition on two numbers and then prints the sum on the screen. For example if the user entered two numbers as 5, 6 then 11 (5 + 6) will be printed on the screen. */

var number1: Int = 5
var number2: Int = 6
var addition1 = number1 + number2

// Adding operation using function

func addition(_ a:Int, _ b:Int) -> Int {
    let add = a + b
    return add
}
addition(10, 40)
addition(20, 20)